<?php
class Wage extends AppModel {
	var $name = 'Wage';
}
?>