<?php
class UserImage extends AppModel{
	var $name =  'UserImage';
}
?>