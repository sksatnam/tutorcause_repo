<?php
class State extends AppModel
{
	var $name = 'State';
}
?>