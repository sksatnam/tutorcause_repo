<?php
class Charge extends AppModel {
	var $name = 'Charge';
}
?>