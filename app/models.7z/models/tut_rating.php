<?php 
class TutRating extends AppModel {
	var $name = 'TutRating';
}
?> 