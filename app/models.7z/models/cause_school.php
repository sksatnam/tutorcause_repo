<?php
class CauseSchool extends AppModel{
	var $name =  'CauseSchool';
}
?>