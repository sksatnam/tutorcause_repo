tinyMCE.addI18n('en.asciisvg',{
	desc : 'Add/Edit Graph'
});
