<?php
class Api extends AppModel {
	var $name = 'Api';
}
?>