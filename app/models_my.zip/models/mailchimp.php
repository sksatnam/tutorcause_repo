<?php
class Mailchimp extends AppModel{
	var $name =  'Mailchimp';
	}

?>